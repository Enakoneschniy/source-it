$(document).ready(function(){


function setheight(divs){

var arrheight= []
for(var  i=0; i<divs.length; i++ ){
	
arrheight.push( parseInt(computedStyle = getComputedStyle(divs[i], null).getPropertyValue("height")));

}


var maxheight = Math.max.apply(null, arrheight);


for(var  j=0; j<divs.length; j++ ){

divs[j].style.height = maxheight+"px";


}


}// setheight




 setheight($(".box"));
  setheight($(".block"));


  $("#btn-clean").click(function(e){
  e.stopPropagation();
  document.getElementById("text").value = "";
  document.getElementById("password").value = "";
})





$( ".list li:first-child" )
  .css( "color", "red" );



function chetn(){
var cheelemetns = $( ".list li:nth-child(even)")
for(var  p=0; p<cheelemetns.length; p++ ){
var nom =$(cheelemetns[p]).html().charAt(10);

 $(cheelemetns[p]).prepend(nom);


}






}

$("li").click(function(e){
 var arr = $(this).parent().children();
	for(var  o=0; o<arr.length; o++ ){

$("arr[o]").addClass( "none" );
}
	$(this).addClass( "active" );
	
})






chetn();


   })// eof
